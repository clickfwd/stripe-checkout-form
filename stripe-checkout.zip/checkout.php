<?php
require_once('vendor/autoload.php');

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array
$amount = $input['amount'] ?? null;

if ( $amount > 0 ) 
{
	\Stripe\Stripe::setApiKey('sk_live_1234567890');

	$res = \Stripe\Checkout\Session::create([
	  'success_url' => 'https://www.domain.com/payment/success.html',
	  'cancel_url' => 'https://www.domain.com/customdev/canceled.html',
	  'payment_method_types' => ['card'],
	  'line_items' => [
	    [
	      'name' => 'Custom Development',
	      'description' => 'Custom Development',
	      'amount' => $amount * 100,
	      'currency' => 'usd',
	      'quantity' => 1,
	    ],
	  ],
	]);

	echo json_encode(
		['session_id' => $res['id'], 'success' => true]
	);
}
else {
	echo json_encode(
		['success' => false]
	);
}
